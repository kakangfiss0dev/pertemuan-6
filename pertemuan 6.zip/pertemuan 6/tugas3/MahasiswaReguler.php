<?php
declare(strict_types=1);
require_once __DIR__ . '/Mahasiswa.php';

/** CHILD 1: mahasiswa reguler membayar UKT penuh. */
final class MahasiswaReguler extends Mahasiswa
{
    private int $ukt;

    public function __construct(
        string $nim, string $nama, string $fakultas, string $prodi,
        string $asalSekolah, int $semester, string $hobi, string $agama, int $ukt
    ) {
        // Data umum diisi dan divalidasi oleh parent, lalu child memvalidasi data khususnya.
        parent::__construct($nim, $nama, $fakultas, $prodi, $asalSekolah, $semester, $hobi, $agama);
        if ($ukt < 0) {
            throw new InvalidArgumentException('UKT tidak boleh negatif.');
        }
        $this->ukt = $ukt;
    }

    public function getUkt(): int { return $this->ukt; }
    public function getJenis(): string { return 'Reguler'; }

    // Overriding: biaya akhir = UKT penuh.
    public function hitungBiaya(): int { return $this->ukt; }
}
