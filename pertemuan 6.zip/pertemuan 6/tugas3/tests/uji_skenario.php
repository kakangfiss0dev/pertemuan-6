<?php
declare(strict_types=1);
require_once __DIR__ . '/../DataMahasiswa.php';
if (PHP_SAPI !== 'cli') echo '<pre>';

// Warning PHP (mis. akses property) diubah jadi exception supaya bisa dicetak rapi.
set_error_handler(function (int $no, string $msg) { throw new ErrorException($msg); });

function rp(int $n): string { return number_format($n, 0, ',', '.'); }

function buatReguler(string $nim = '23001', string $nama = 'Andi', int $semester = 4, int $ukt = 5000000): MahasiswaReguler {
    return new MahasiswaReguler($nim, $nama, 'Sains dan Teknologi', 'Informatika', 'SMAN 1', $semester, 'Musik', 'Islam', $ukt);
}
function buatBeasiswa(string $nim = '23002', string $nama = 'Siti', int $ukt = 5000000, int $potongan = 60): MahasiswaBeasiswa {
    return new MahasiswaBeasiswa($nim, $nama, 'Sains dan Teknologi', 'Informatika', 'SMAN 2', 4, 'Membaca', 'Islam', $ukt, $potongan);
}

/** Menentukan lapisan yang menolak berdasarkan file tempat exception dibuat. */
function lapisan(Throwable $e): string {
    $f = basename($e->getFile());
    if ($f === 'Mahasiswa.php') return 'parent constructor';
    if ($f === 'MahasiswaReguler.php' || $f === 'MahasiswaBeasiswa.php') return 'child constructor';
    if ($f === 'DataMahasiswa.php') return 'repository';
    return $f;
}
/** @return array{0:string,1:bool} */
function tolakKonstruktor(callable $buat, string $lapisanHarapan): array {
    try { $buat(); return ['DITERIMA (seharusnya ditolak)', false]; }
    catch (InvalidArgumentException $e) {
        $l = lapisan($e);
        return ['Ditolak ' . $l . ': ' . $e->getMessage(), $l === $lapisanHarapan];
    }
}

$sesuai = 0;
$total = 0;
function skenario(string $no, string $nama, string $harapan, callable $fn): void {
    global $sesuai, $total;
    $total++;
    try { [$aktual, $ok] = $fn(); }
    catch (Throwable $e) { $aktual = 'ERROR tak terduga: ' . $e->getMessage(); $ok = false; }
    if ($ok) $sesuai++;
    echo $no . ' | ' . $nama . PHP_EOL;
    echo '   Diharapkan : ' . $harapan . PHP_EOL;
    echo '   Aktual     : ' . $aktual . PHP_EOL;
    echo '   Status     : ' . ($ok ? 'SESUAI' : 'TIDAK SESUAI') . PHP_EOL . PHP_EOL;
}

echo "=== HASIL PENGUJIAN CRUD MAHASISWA (INHERITANCE) ===" . PHP_EOL . PHP_EOL;

skenario('01', 'Tambah Reguler UKT 5.000.000', 'Biaya akhir 5.000.000', function () {
    $m = buatReguler();
    return ['Biaya akhir ' . rp($m->hitungBiaya()), $m->hitungBiaya() === 5000000];
});

skenario('02', 'Tambah Beasiswa UKT 5.000.000; potongan 60%', 'Biaya akhir 2.000.000', function () {
    $m = buatBeasiswa('23002', 'Siti', 5000000, 60);
    return ['Biaya akhir ' . rp($m->hitungBiaya()), $m->hitungBiaya() === 2000000];
});

skenario('03', 'NIM kosong', 'Ditolak parent constructor', function () {
    return tolakKonstruktor(fn() => buatReguler(''), 'parent constructor');
});

skenario('04', 'Semester 0 atau 15', 'Ditolak parent constructor', function () {
    $a = tolakKonstruktor(fn() => buatReguler('23001', 'Andi', 0), 'parent constructor');
    $b = tolakKonstruktor(fn() => buatReguler('23001', 'Andi', 15), 'parent constructor');
    $pisah = PHP_EOL . '                 ';
    return ['semester 0  -> ' . $a[0] . $pisah . 'semester 15 -> ' . $b[0], $a[1] && $b[1]];
});

skenario('05', 'UKT -100', 'Ditolak child constructor', function () {
    return tolakKonstruktor(fn() => buatReguler('23001', 'Andi', 4, -100), 'child constructor');
});

skenario('06', 'Potongan 120%', 'Ditolak child constructor', function () {
    return tolakKonstruktor(fn() => buatBeasiswa('23002', 'Siti', 5000000, 120), 'child constructor');
});

skenario('07', 'NIM duplikat', 'Ditolak repository', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buatReguler('23001'));
    $ditolak = !$repo->tambah(buatReguler('23001'));
    return [
        $ditolak ? 'Ditolak repository (tambah() mengembalikan false); jumlah record tetap ' . count($repo->semua()) : 'DITERIMA',
        $ditolak && count($repo->semua()) === 1,
    ];
});

skenario('08', 'Edit Reguler menjadi Beasiswa pada NIM sama', 'Jenis berubah; data tetap satu record', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buatReguler('23001'));
    $awal = $repo->cari('23001')->getJenis();
    $berhasil = $repo->ubah('23001', buatBeasiswa('23001', 'Andi', 5000000, 60));
    $akhir = $repo->cari('23001')->getJenis();
    $jumlah = count($repo->semua());
    return [
        "Jenis berubah {$awal} -> {$akhir}; jumlah record = {$jumlah}; biaya akhir Rp " . rp($repo->cari('23001')->hitungBiaya()),
        $berhasil && $awal === 'Reguler' && $akhir === 'Beasiswa' && $jumlah === 1,
    ];
});

skenario('09', 'Edit dengan NIM berbeda', 'Ditolak repository', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buatReguler('23001'));
    $ditolak = !$repo->ubah('23001', buatBeasiswa('23999', 'Andi', 5000000, 60));
    $utuh = $repo->cari('23001')->getJenis() === 'Reguler' && $repo->cari('23999') === null;
    return [
        $ditolak ? 'Ditolak repository (ubah() mengembalikan false); data lama tetap utuh' : 'DITERIMA',
        $ditolak && $utuh,
    ];
});

skenario('10', 'Hapus satu record', 'Record lain tetap tersedia', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buatReguler('23001'));
    $repo->tambah(buatBeasiswa('23002'));
    $terhapus = $repo->hapus('23001');
    $ok = $terhapus && $repo->cari('23001') === null && $repo->cari('23002') !== null;
    return ['Record 23001 terhapus; sisa record = ' . count($repo->semua()) . ' (23002 masih ada)', $ok];
});

skenario('11', 'Refresh browser selama Session aktif', 'Data tetap ada', function () {
    $repo = new DataMahasiswa();
    $repo->tambah(buatReguler('23001'));
    $repo->tambah(buatBeasiswa('23002'));
    // Simulasi PHP Session: object disimpan sebagai serialize lalu dipulihkan di request berikutnya.
    $tersimpan = serialize($repo->semua());
    $pulih = new DataMahasiswa(unserialize($tersimpan));
    $ok = count($pulih->semua()) === 2 && $pulih->cari('23002')?->hitungBiaya() === 2000000;
    return ['Data tetap ada setelah serialize/unserialize (cara kerja Session): ' . count($pulih->semua()) . ' record', $ok];
});

skenario('12', 'Akses $m->nim langsung', 'Ditolak karena private', function () {
    $m = buatReguler();
    try { $x = $m->nim; return ['DITERIMA (salah!)', false]; }
    catch (Throwable $e) { return ['Ditolak: ' . $e->getMessage(), true]; }
});

echo "Ringkasan: {$sesuai} dari {$total} skenario SESUAI" . PHP_EOL;
echo "Catatan: skenario 11 disimulasikan di sini; untuk bukti asli, screenshot browser sebelum dan sesudah refresh (F5) di index.php." . PHP_EOL;
