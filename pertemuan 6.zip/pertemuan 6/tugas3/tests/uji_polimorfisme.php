<?php
declare(strict_types=1);
require_once __DIR__ . '/../DataMahasiswa.php';
if (PHP_SAPI !== 'cli') echo '<pre>';

// Eksperimen kunci modul (Bagian G): satu method, perilaku berbeda.
$daftar = [
    new MahasiswaReguler('23001', 'Andi', 'Sains dan Teknologi', 'Informatika', 'SMAN 1', 4, 'Musik', 'Islam', 5000000),
    new MahasiswaBeasiswa('23002', 'Siti', 'Sains dan Teknologi', 'Informatika', 'SMAN 2', 4, 'Membaca', 'Islam', 5000000, 60),
];

echo "=== Biaya akhir (tanpa instanceof) ===" . PHP_EOL;
foreach ($daftar as $m) {
    echo $m->getNama() . ' / ' . $m->getJenis()
        . ' / Rp' . number_format($m->hitungBiaya(), 0, ',', '.') . PHP_EOL;
}

echo PHP_EOL . "=== Hubungan is-a ===" . PHP_EOL;
foreach ($daftar as $m) {
    echo $m->getNama() . ' instanceof Mahasiswa        : ' . ($m instanceof Mahasiswa ? 'ya' : 'tidak') . PHP_EOL;
}

echo PHP_EOL . "=== parent::getRingkasan() pada child ===" . PHP_EOL;
foreach ($daftar as $m) {
    echo $m->getRingkasan() . PHP_EOL;
}
