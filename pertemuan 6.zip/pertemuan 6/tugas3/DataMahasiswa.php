<?php
declare(strict_types=1);
require_once __DIR__ . '/MahasiswaReguler.php';
require_once __DIR__ . '/MahasiswaBeasiswa.php';

/**
 * Repository sederhana. Semua parameter bertipe Mahasiswa (parent), sehingga menerima
 * MahasiswaReguler maupun MahasiswaBeasiswa tanpa percabangan if/instanceof.
 */
final class DataMahasiswa
{
    /** @var array<string, Mahasiswa> */
    private array $data = [];

    /** @param array<string, Mahasiswa> $dataAwal */
    public function __construct(array $dataAwal = [])
    {
        foreach ($dataAwal as $item) {
            if ($item instanceof Mahasiswa) {
                $this->data[$item->getNim()] = $item;
            }
        }
    }

    /** @return array<string, Mahasiswa> */
    public function semua(): array { return $this->data; }

    public function cari(string $nim): ?Mahasiswa { return $this->data[$nim] ?? null; }

    /** Pencarian kata kunci pada NIM, nama, prodi, dan jenis. @return array<string, Mahasiswa> */
    public function cariKata(string $kata): array
    {
        $kata = trim($kata);
        if ($kata === '') return $this->data;
        return array_filter($this->data, static function (Mahasiswa $m) use ($kata): bool {
            $gabung = $m->getNim() . ' ' . $m->getNama() . ' ' . $m->getProdi() . ' ' . $m->getJenis();
            return stripos($gabung, $kata) !== false;
        });
    }

    public function tambah(Mahasiswa $mahasiswa): bool
    {
        $nim = $mahasiswa->getNim(); // Bukan $mahasiswa->nim (private).
        if (isset($this->data[$nim])) return false;
        $this->data[$nim] = $mahasiswa;
        return true;
    }

    /** NIM tidak boleh berubah. Mengganti jenis = memasang object child baru pada NIM yang sama. */
    public function ubah(string $nimLama, Mahasiswa $mahasiswa): bool
    {
        if (!isset($this->data[$nimLama]) || $mahasiswa->getNim() !== $nimLama) return false;
        $this->data[$nimLama] = $mahasiswa;
        return true;
    }

    public function hapus(string $nim): bool
    {
        if (!isset($this->data[$nim])) return false;
        unset($this->data[$nim]);
        return true;
    }
}
