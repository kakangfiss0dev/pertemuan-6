<?php
declare(strict_types=1);
require_once __DIR__ . '/PegawaiTetap.php';
require_once __DIR__ . '/PegawaiKontrak.php';
if (PHP_SAPI !== 'cli') echo '<pre>';

function rp(int $n): string { return 'Rp ' . number_format($n, 0, ',', '.'); }

$tetap = new PegawaiTetap('P001', 'Budi Santoso', 5000000);
$kontrak = new PegawaiKontrak('K001', 'Dewi Lestari', 50000, 120);

echo "=== Objek 1: PegawaiTetap ===" . PHP_EOL;
echo 'ID          : ' . $tetap->getId() . PHP_EOL;
echo 'Nama        : ' . $tetap->getNama() . PHP_EOL;
echo 'Jenis       : ' . $tetap->getJenis() . PHP_EOL;
echo 'Gaji pokok  : ' . rp($tetap->getGajiPokok()) . PHP_EOL;
echo 'Gaji        : ' . rp($tetap->hitungGaji()) . PHP_EOL . PHP_EOL;

echo "=== Objek 2: PegawaiKontrak ===" . PHP_EOL;
echo 'ID          : ' . $kontrak->getId() . PHP_EOL;
echo 'Nama        : ' . $kontrak->getNama() . PHP_EOL;
echo 'Jenis       : ' . $kontrak->getJenis() . PHP_EOL;
echo 'Upah per jam: ' . rp($kontrak->getUpahPerJam()) . ' x ' . $kontrak->getJamKerja() . ' jam' . PHP_EOL;
echo 'Gaji        : ' . rp($kontrak->hitungGaji()) . PHP_EOL . PHP_EOL;

echo "=== Polimorfisme: satu method, hasil berbeda ===" . PHP_EOL;
foreach ([$tetap, $kontrak] as $p) {
    echo str_pad($p->getNama(), 14) . ' | ' . str_pad($p->getJenis(), 16) . ' | ' . rp($p->hitungGaji()) . PHP_EOL;
}
echo PHP_EOL;

echo "=== Uji validasi angka negatif ===" . PHP_EOL;
$percobaan = [
    'PegawaiTetap gaji pokok -1'      => fn() => new PegawaiTetap('P002', 'Andi', -1),
    'PegawaiKontrak upah per jam -5'  => fn() => new PegawaiKontrak('K002', 'Sari', -5, 10),
    'PegawaiKontrak jam kerja -10'    => fn() => new PegawaiKontrak('K003', 'Rina', 50000, -10),
    'PegawaiTetap nama kosong'        => fn() => new PegawaiTetap('P003', '  ', 3000000),
];
foreach ($percobaan as $label => $buat) {
    try { $buat(); echo str_pad($label, 34) . ' => DITERIMA (salah!)' . PHP_EOL; }
    catch (InvalidArgumentException $e) { echo str_pad($label, 34) . ' => Ditolak: ' . $e->getMessage() . PHP_EOL; }
}
