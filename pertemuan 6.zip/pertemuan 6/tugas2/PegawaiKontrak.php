<?php
declare(strict_types=1);
require_once __DIR__ . '/Pegawai.php';

final class PegawaiKontrak extends Pegawai
{
    public function __construct(string $id, string $nama, private int $upahPerJam, private int $jamKerja)
    {
        parent::__construct($id, $nama);
        if ($upahPerJam < 0 || $jamKerja < 0) {
            throw new InvalidArgumentException('Upah per jam dan jam kerja tidak boleh negatif.');
        }
    }

    public function getUpahPerJam(): int { return $this->upahPerJam; }
    public function getJamKerja(): int { return $this->jamKerja; }
    public function getJenis(): string { return 'Pegawai Kontrak'; }

    // Overriding: gaji kontrak = upah per jam x jam kerja.
    public function hitungGaji(): int { return $this->upahPerJam * $this->jamKerja; }
}
