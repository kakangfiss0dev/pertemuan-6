<?php
declare(strict_types=1);

/** PARENT (abstract): data umum pegawai. Cara hitung gaji ditentukan oleh child. */
abstract class Pegawai
{
    public function __construct(private string $id, private string $nama)
    {
        if (trim($id) === '' || trim($nama) === '') {
            throw new InvalidArgumentException('ID dan nama pegawai wajib diisi.');
        }
        $this->id = trim($id);
        $this->nama = trim($nama);
    }

    public function getId(): string { return $this->id; }
    public function getNama(): string { return $this->nama; }

    abstract public function getJenis(): string;
    abstract public function hitungGaji(): int;
}
