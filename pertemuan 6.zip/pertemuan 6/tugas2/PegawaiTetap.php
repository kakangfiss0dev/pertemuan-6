<?php
declare(strict_types=1);
require_once __DIR__ . '/Pegawai.php';

final class PegawaiTetap extends Pegawai
{
    public function __construct(string $id, string $nama, private int $gajiPokok)
    {
        parent::__construct($id, $nama);
        if ($gajiPokok < 0) {
            throw new InvalidArgumentException('Gaji pokok tidak boleh negatif.');
        }
    }

    public function getGajiPokok(): int { return $this->gajiPokok; }
    public function getJenis(): string { return 'Pegawai Tetap'; }

    // Overriding: gaji tetap = gaji pokok.
    public function hitungGaji(): int { return $this->gajiPokok; }
}
