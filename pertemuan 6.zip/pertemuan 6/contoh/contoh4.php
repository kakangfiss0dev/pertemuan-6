<?php
// Contoh 4 - method overriding
if (PHP_SAPI !== 'cli') echo '<pre>';

class Mahasiswa {
    public function hitungBiaya(): int { return 5000000; }
}
class MahasiswaBeasiswa extends Mahasiswa {
    public function hitungBiaya(): int { return 2000000; }
}

$a = new Mahasiswa();
$b = new MahasiswaBeasiswa();
echo $a->hitungBiaya() . ' | ' . $b->hitungBiaya() . PHP_EOL;   // 5000000 | 2000000
