<?php
// Contoh 3 - private versus protected
if (PHP_SAPI !== 'cli') echo '<pre>';

class Mahasiswa {
    private string $nim = '23001';
    protected string $kategori = 'Mahasiswa';
    public function getNim(): string { return $this->nim; }
}
class MahasiswaReguler extends Mahasiswa {
    public function info(): string {
        // return $this->nim; // SALAH: private milik parent
        return $this->getNim() . ' / ' . $this->kategori;
    }
}

echo (new MahasiswaReguler())->info() . PHP_EOL;   // 23001 / Mahasiswa

// Tambahan eksperimen: akses langsung dari luar class (warning/error ditangkap supaya rapi)
set_error_handler(function (int $no, string $msg) { throw new ErrorException($msg); });
$m = new MahasiswaReguler();
echo PHP_EOL . 'Akses $m->nim dari luar      : ';
try { echo $m->nim; } catch (Throwable $e) { echo 'Ditolak -> ' . $e->getMessage(); }
echo PHP_EOL . 'Akses $m->kategori dari luar : ';
try { echo $m->kategori; } catch (Throwable $e) { echo 'Ditolak -> ' . $e->getMessage(); }
echo PHP_EOL;
