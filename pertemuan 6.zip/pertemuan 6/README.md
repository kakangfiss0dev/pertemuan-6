# Praktikum PBO Pertemuan 06 - Inheritance (PHP 8+)

Nama: [isi nama / kelompok] | NIM: [isi NIM] | Dosen: Prajoko, M.Kom.

| Folder | Isi |
|---|---|
| `contoh/` | Contoh 1-5 dari modul (extends, parent::__construct, private vs protected, overriding, trait) |
| `tugas2/` | Tugas 2: `Pegawai`, `PegawaiTetap`, `PegawaiKontrak`, `uji_pegawai.php` |
| `tugas3/` | Tugas 3: CRUD Mahasiswa (lanjutan Pertemuan 5) dengan parent abstract + 2 child |
| `tugas3/tests/` | `uji_skenario.php` (12 skenario modul), `uji_polimorfisme.php` (eksperimen kunci) |

Cara jalan (XAMPP): salin folder ini ke `C:\xampp\htdocs\PBO-6`, start Apache, lalu buka:

- `http://localhost/PBO-6/contoh/contoh1.php` ... `contoh5.php`
- `http://localhost/PBO-6/tugas2/uji_pegawai.php`
- `http://localhost/PBO-6/tugas3/index.php`
- `http://localhost/PBO-6/tugas3/tests/uji_skenario.php`
- `http://localhost/PBO-6/tugas3/tests/uji_polimorfisme.php`

Atau lewat terminal: `C:\xampp\php\php.exe tugas3\tests\uji_skenario.php`

## Panduan screenshot untuk laporan

| Bagian laporan | Yang di-screenshot |
|---|---|
| Hasil eksperimen contoh 1-5 | Browser: `contoh/contoh1.php` s.d. `contoh5.php` (output sesuai komentar di tiap file) |
| Potongan kode: extends, parent::__construct(), overriding | VS Code: `MahasiswaReguler.php` (baris `extends` + constructor) dan `hitungBiaya()` di kedua child |
| Tugas 2 (Pegawai) | Kode ketiga class + browser `tugas2/uji_pegawai.php` |
| CRUD: tambah Reguler | `index.php`, isi form jenis Reguler lalu tambah |
| CRUD: tambah Beasiswa | Jenis Beasiswa, UKT 5000000, potongan 60 (biaya akhir 2.000.000) |
| CRUD: cari / edit / hapus | Kotak Cari; tombol Edit (ganti jenis, NIM terkunci); tombol Hapus |
| Tabel 12 pengujian | `tugas3/tests/uji_skenario.php`; skenario 11 tambah screenshot browser sebelum/sesudah F5 |
| Eksperimen kunci (Bagian G) | `tugas3/tests/uji_polimorfisme.php` |

Validasi di form sengaja memakai `novalidate`, jadi pesan error dari class PHP (NIM kosong, semester 0/15, UKT -100, potongan 120, NIM duplikat) bisa langsung di-screenshot.
